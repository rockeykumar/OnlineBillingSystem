﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
public partial class find_two_wheeler_exe : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        Panel2.Visible = false;
        Panel3.Visible = false;
        if (!IsPostBack)
        {
            try
            {
                SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["hero_connect"].ConnectionString);
                SqlDataAdapter da = new SqlDataAdapter("select Model from BikeModel", con);
                DataSet ds = new DataSet();
                da.Fill(ds);
                if (ds.Tables[0].Rows.Count > 0)
                {
                    ddfindbike.DataSource = ds.Tables[0];
                    ddfindbike.DataTextField = ds.Tables[0].Columns["Model"].ToString();
                    ddfindbike.DataValueField = ds.Tables[0].Columns["Model"].ToString();

                    ddfindbike.DataBind();
                    ddfindbike.Items.Insert(0, "select");
                }
            }

            catch (Exception ex)
            {
                Response.Write(ex.Message.ToString());
            }
        }
    }
    protected void btSearch_Click1(object sender, EventArgs e)
    {
        Panel1.Visible = false;
        Panel2.Visible = true;
        Panel3.Visible = false;

        try
        {
            SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["hero_connect"].ConnectionString);
            SqlDataAdapter da = new SqlDataAdapter("select * from BikeModel where Model ='" + ddfindbike.SelectedValue.ToString() + "'", con);
            DataSet ds = new DataSet();
            da.Fill(ds);
            if (ds.Tables[0].Rows.Count > 0)
            {
                lb1.Text = ds.Tables[0].Rows[0]["Model"].ToString();
                lb2.Text = ds.Tables[0].Rows[0]["Type"].ToString();
                lb3.Text = ds.Tables[0].Rows[0]["Maker"].ToString();
                lb4.Text = ds.Tables[0].Rows[0]["Fuel"].ToString();
                lb5.Text = ds.Tables[0].Rows[0]["N_o_c"].ToString();
                lb7.Text = ds.Tables[0].Rows[0]["Seat"].ToString();
                lb8.Text = "Kg. " + ds.Tables[0].Rows[0]["K_weight"].ToString();
                lb9.Text = ds.Tables[0].Rows[0]["B_type"].ToString();
                lb10.Text = ds.Tables[0].Rows[0]["H_power"].ToString();
                lb11.Text = "Rs. " + ds.Tables[0].Rows[0]["Mrp"].ToString();

            }

            else if (ddfindbike.SelectedValue.ToString() == "select")
            {
                //string.IsNullOrEmpty(ddfindbike.SelectedValue.ToString());
                lbans.Text = "Please select Model....";

                Panel1.Visible = true;
                Panel2.Visible = false;
            }
        }

        catch (Exception ex)
        {
            Response.Write(ex.Message.ToString());
        }



        //  lb1.Text = ddfindbike.SelectedItem.ToString();
    }
    protected void ddfindbike_SelectedIndexChanged(object sender, EventArgs e)
    {

    }

    protected void btorder_Click(object sender, EventArgs e)
    {
        Panel1.Visible = false;
        Panel2.Visible = false;
        Panel3.Visible = true;

        try
        {
            SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["hero_connect"].ConnectionString);
            SqlDataAdapter da = new SqlDataAdapter("select * from BikeModel where Model ='" + ddfindbike.SelectedValue.ToString() + "'", con);
            DataSet ds = new DataSet();
            da.Fill(ds);
            if (ds.Tables[0].Rows.Count > 0)
            {
                lbmodel.Text = ds.Tables[0].Rows[0]["Model"].ToString();
            }

            else if (ddfindbike.SelectedValue.ToString() == "select")
            {
                //string.IsNullOrEmpty(ddfindbike.SelectedValue.ToString());
                lbans.Text = "Please select Model....";

                Panel1.Visible = true;
                Panel2.Visible = false;
            }
        }

        catch (Exception ex)
        {
            Response.Write(ex.Message.ToString());
        }


    }
    protected void btconfirm_Click(object sender, EventArgs e)
    {
        //Panel1.Visible = true                                                                                                                                                          ;
        //Panel2.Visible = false;
        Panel3.Visible = true;

        string colorcode = null;
        colorcode = ddcolor.SelectedItem.ToString();

        if (ddcolor.SelectedValue.ToString() == "select")
        {
            llbans.Text = "Please choose color...";
            return;
        }

        if (txtfirstname.Text == "")
        {
            llbans.Text = "Please Enter First Name...";
            return;
        }

        if (txtlname.Text == "")
        {
            llbans.Text = "Please Enter Last Name...";
            return;
        }

        if (txtaddress.Text == "")
        {
            llbans.Text = "Please Enter Address...";
            return;
        }

        if (txtemail.Text == "")
        {
            llbans.Text = "Please Enter E-mail...";
            return;
        }

        if (txtmobile.Text == "")
        {
            llbans.Text = "Please Enter Mobile No. ...";
            return;
        }

        try
        {


            SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["hero_connect"].ConnectionString);
            SqlConnection con2 = new SqlConnection(ConfigurationManager.ConnectionStrings["hero_connect"].ConnectionString);
            //SqlDataAdapter da = new SqlDataAdapter("select * from MCUSTOMER where Model = ' "+lbmodel.Text+" ' ", con);

            //DataSet ds = new DataSet();

            //da.Fill(ds);

            //if (ds.Tables[0].Rows.Count == 0)
            //{
            SqlCommand cmd = new SqlCommand("insert into MCUSTOMER(Fname, Lname, Address, email, mobile, Color, Model) values (@Fname, @Lname, @Address, @email, @mobile, @Color, @Model)", con);
            cmd.Parameters.Add("@Fname", SqlDbType.VarChar).Value = txtfirstname.Text;
            cmd.Parameters.Add("@Lname", SqlDbType.VarChar).Value = txtlname.Text;
            cmd.Parameters.Add("@Address", SqlDbType.VarChar).Value = txtaddress.Text;
            cmd.Parameters.Add("@email", SqlDbType.VarChar).Value = txtemail.Text;
            cmd.Parameters.Add("@Ph", SqlDbType.VarChar).Value = txtmobile.Text;
            cmd.Parameters.Add("@mobile", SqlDbType.VarChar).Value = txtmobile.Text;
            cmd.Parameters.Add("@Color", SqlDbType.VarChar).Value = colorcode;
            cmd.Parameters.Add("@Model", SqlDbType.VarChar).Value = lbmodel.Text;
            con.Open();
            cmd.ExecuteNonQuery();
            con.Close();


            SqlCommand cmd2 = new SqlCommand("insert into ORDER_BIKE(email, Color, Model) values (@email, @Color, @Model)", con2);

            cmd2.Parameters.Add("@email", SqlDbType.VarChar).Value = txtemail.Text;
            cmd2.Parameters.Add("@Color", SqlDbType.VarChar).Value = colorcode;
            cmd2.Parameters.Add("@Model", SqlDbType.VarChar).Value = lbmodel.Text;
            con2.Open();
            cmd2.ExecuteNonQuery();
            con2.Close();

            llbans.Text = "Order successfully...";
            //}

            //else
            //{
            //    llbans.Text = "Unable to order...";
            //}
        }

        catch (Exception ex)
        {
            Response.Write(ex.Message.ToString());
        }

    }

    protected void ddcolor_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
    protected void btback2_Click(object sender, EventArgs e)
    {
        Panel1.Visible = false;
        Panel2.Visible = true;
        Panel3.Visible = false;
    }
    protected void btback1_Click(object sender, EventArgs e)
    {
        Panel1.Visible = true;
        Panel2.Visible = false;
        Panel3.Visible = false;
    }
}