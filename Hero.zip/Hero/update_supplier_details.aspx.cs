﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;


public partial class update_supplier_details : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void btinsert_Click(object sender, EventArgs e)
    {
        if (txtsupplier.Text == "")
        {
            lbans.Text = "Enter Supplier Name...";
            return;
        }

        if (txtsupplieraddress.Text == "")
        {
            lbans.Text = "Enter Supplier Address...";
            return;
        }

        if (txtdistrict.Text == "")
        {
            lbans.Text = "Enter District Name...";
            return;
        }

        if (txtstate.Text == "")
        {
            lbans.Text = "Enter State Name...";
            return;
        }

        if (txtmobile.Text == "")
        {
            lbans.Text = "Enter Mobile No...";
            return;
        }

        try
        {
            SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["hero_connect"].ConnectionString);
            SqlDataAdapter da = new SqlDataAdapter("select * from MSupplier where Mobile = ' " +txtmobile+ " ' ", con);
            DataSet ds = new DataSet();
            da.Fill(ds);
            if (ds.Tables[0].Rows.Count == 0)
            {
                SqlCommand cmd = new SqlCommand("insert into MSupplier(Supp_name, Supp_add, District, State, Ph_no, Mobile, Email) values (@Supp_name, @Supp_add, @District, @State, @Ph_no, @mobile, @Email)", con);

                cmd.Parameters.Add("@Supp_name", SqlDbType.VarChar).Value = txtsupplier.Text;
                cmd.Parameters.Add("@Supp_add", SqlDbType.VarChar).Value = txtsupplieraddress.Text;
                cmd.Parameters.Add("@District", SqlDbType.VarChar).Value = txtdistrict.Text;
                cmd.Parameters.Add("@State", SqlDbType.VarChar).Value = txtstate.Text;
                cmd.Parameters.Add("@Ph_no", SqlDbType.VarChar).Value = txtphone.Text;
                cmd.Parameters.Add("@mobile", SqlDbType.VarChar).Value = txtmobile.Text;
                cmd.Parameters.Add("@Email", SqlDbType.VarChar).Value = txtemail.Text;
                

                con.Open();
                cmd.ExecuteNonQuery();
                con.Close();
                lbans.Text = "Data Inserted successfully...";
            }
            else
            {
                lbans.Text = "Data alredy exists...";
            }
        }
        catch (Exception ex)
        {
            Response.Write(ex.Message.ToString());
        }
    }
    protected void btupdate_Click(object sender, EventArgs e)
    {
        if (txtsupplier.Text == "")
        {
            lbans.Text = "Enter Supplier Name...";
            return;
        }

        if (txtsupplieraddress.Text == "")
        {
            lbans.Text = "Enter Supplier Address...";
            return;
        }

        if (txtdistrict.Text == "")
        {
            lbans.Text = "Enter District Name...";
            return;
        }

        if (txtstate.Text == "")
        {
            lbans.Text = "Enter State Name...";
            return;
        }

        if (txtmobile.Text == "")
        {
            lbans.Text = "Enter Mobile No...";
            return;
        }

        try
        {
            SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["hero_connect"].ConnectionString);
            SqlDataAdapter da = new SqlDataAdapter("select * from MSupplier where Mobile ='"+txtmobile.Text+"' ", con);
            DataSet ds = new DataSet();
            da.Fill(ds);
            if (ds.Tables[0].Rows.Count == 1)
            {
                SqlCommand cmd = new SqlCommand("update MSupplier set Supp_name ='"+txtsupplier.Text+"', Supp_add='"+txtsupplieraddress.Text+"', District='"+txtdistrict.Text+"', State='"+txtstate.Text+"', Ph_no='"+txtphone.Text+"', Email='"+txtemail.Text+"' where Mobile ='"+txtmobile.Text+"' ", con);

                con.Open();
                cmd.ExecuteNonQuery();
                con.Close();
                lbans.Text = "Data Update Successfully...";
            }

            else
            {
                lbans.Text = "Enable To Update Password...";
            }
        }

        catch (Exception ex)
        {
            Response.Write(ex.Message.ToString());
        }
        
    }
    protected void clear_Click(object sender, EventArgs e)
    {
        txtsupplier.Text = "";
        txtsupplieraddress.Text = "";
        txtdistrict.Text = "";
        txtstate.Text = "";
        txtphone.Text = "";
        txtmobile.Text = "";
        txtemail.Text = "";
    }
    protected void btdelete_Click1(object sender, EventArgs e)
    {
        try
        {
            SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["hero_connect"].ConnectionString);
            SqlCommand cmd = new SqlCommand("delete from MSupplier where Mobile ='"+txtmobiledel.Text+"' ", con);
            con.Open();
            cmd.ExecuteNonQuery();
            con.Close();
            lbans.Text = "Recored Deleted...";
        }

        catch (Exception ex)
        {
            Response.Write(ex.Message.ToString());
        }
        
    }
}