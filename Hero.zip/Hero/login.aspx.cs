﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

public partial class login : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
    
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        if (txtUname.Text == "")
        {
            uname.Text = "Enter User name...";
            return;
        }

        if (txtpassword.Text == "")
        {
            lpassword.Text = "Enter password...";
            return;
        }

        try
        {
            SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["hero_connect"].ConnectionString);
            SqlConnection con_admin = new SqlConnection(ConfigurationManager.ConnectionStrings["hero_connect"].ConnectionString);
            SqlConnection con_exe = new SqlConnection(ConfigurationManager.ConnectionStrings["hero_connect"].ConnectionString);

            SqlDataAdapter da = new SqlDataAdapter("select * from Client where Uname = '" + txtUname.Text + "' and password = '" + txtpassword.Text + "' ", con);
            SqlDataAdapter da_admin = new SqlDataAdapter("select * from Admin where Uname = '" + txtUname.Text + "' and password = '" + txtpassword.Text + "' ", con_admin);
            SqlDataAdapter da_exe = new SqlDataAdapter("select * from Executive where Uname = '" + txtUname.Text + "' and password = '" + txtpassword.Text + "' ", con_exe);
            
            DataSet ds = new DataSet();
            DataSet ds_admin = new DataSet();
            DataSet ds_exe = new DataSet();
            da.Fill(ds);
            da_admin.Fill(ds_admin);
            da_exe.Fill(ds_exe);

            if (rdclient.Checked == true)
            {
                if (ds.Tables[0].Rows.Count == 1)
                {
                    Session["client"] = txtUname.Text.Trim();
                    Response.Redirect("index_client.aspx");
                }
            }

            else if (rdadmin.Checked == true)
            {

                if (ds_admin.Tables[0].Rows.Count == 1)
                {
                    Session["admin"] = txtUname.Text.Trim();
                    Response.Redirect("admin.aspx");
                }
            }

            else if (rdexe.Checked == true)
            {

                if (ds_exe.Tables[0].Rows.Count == 1)
                {
                    Session["executive"] = txtUname.Text.Trim();
                    Response.Redirect("index.aspx");
                }
            }

            else
            {
                Response.Write("Ivalid user name / password");
            }
        }
        catch (Exception ex)
        {
            Response.Write(ex.Message.ToString());
        }
    }
}