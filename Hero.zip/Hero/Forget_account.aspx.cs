﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

public partial class Forget_account : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        new_name.Visible = false;
        txtNpassword.Visible = false;
        confirm_password.Visible = false;
        txtcnpassword.Visible = false;
        notice.Visible = false;
    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        
        try
        {
            SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["hero_connect"].ConnectionString);
            SqlDataAdapter da = new SqlDataAdapter("select * from Client where Uname = '"+txtUname.Text+"' ", con);
            DataSet ds = new DataSet();
            da.Fill(ds);
            if (ds.Tables[0].Rows.Count == 1)
            {
                new_name.Visible = true;
                txtNpassword.Visible = true;
                confirm_password.Visible = true;
                txtcnpassword.Visible = true;
                red_alert.Text = "User Name Founded...";
            }
            else
            {
                red_alert.Text = "Ivalide User Name...";
            }

            Squestion.Text = ds.Tables[0].Rows[0]["question"].ToString();
        }
        catch (Exception ex)
        {
            Response.Write(ex.Message.ToString());
        }

    }

    protected void gobt_Click(object sender, EventArgs e)
    {
       
        if (txtNpassword.Text != txtcnpassword.Text)
        {
            string msg1 = "alert('Password Do not Matched...!!!');";
            ScriptManager.RegisterStartupScript(this, this.GetType(), "msg1", msg1, true);
            return;
        }
        try
        {
            SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["hero_connect"].ConnectionString);
            SqlDataAdapter da = new SqlDataAdapter("select * from Client where Uname = '" + txtUname.Text + "' ", con);
            DataSet ds = new DataSet();
            da.Fill(ds);
            if (ds.Tables[0].Rows.Count == 1)
            {
                SqlCommand cmd = new SqlCommand("update Client set password = '" + txtNpassword.Text + "' where answer = '" + txtanswer.Text + "' ", con);
                
                con.Open();
                cmd.ExecuteNonQuery();
                con.Close();

                string msg1 =  "alert('Password Change Successfully...!!!');";
                ScriptManager.RegisterStartupScript(this, this.GetType(), "msg1", msg1, true);
               // red_alert.Text = "Password Change Successfully...";
            }

            else
            {
                string msg1 = "alert('Unable to change Password...!!!');";
                ScriptManager.RegisterStartupScript(this, this.GetType(), "msg1", msg1, true);
            }
        }

        catch (Exception ex)
        {
            Response.Write(ex.Message.ToString());
        }
        
    }
    protected void resetbt_Click(object sender, EventArgs e)
    {
        txtUname.Text = "";
        txtNpassword.Text = "";
        txtcnpassword.Text = "";
        txtanswer.Text = "";
        red_alert.Visible = false;
        notice.Visible = false;
    }
}