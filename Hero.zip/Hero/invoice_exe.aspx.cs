﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

public partial class invoice_exe : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        txtinvoice_no.Enabled = false;
    }
    protected void btsubmit_Click(object sender, EventArgs e)
    {
        /*  if (txtdate.Text == "")
          {
              Label2.Text = "Select Date...!";
              return;
          }

          if (txtmechanic.Text == "")
          {
              Label2.Text = "Mechanic...!";
              return;
          }

          if (ddagent_name.SelectedItem.ToString() == "select")
          {
              Label2.Text = "Select Saler by...!";
              return;
          }

          if (ddsale_type.SelectedItem.ToString() == "select")
          {
              Label2.Text = "Select Selar type...!";
              return;
          }

          if (txtbank.Text == "")
          {
              Label2.Text = "Select Bank...!";
              return;
          }

          if (txtremark.Text == "")
          {
              Label2.Text = "Write Bank Location...!";
              return;
          }

          if (txtname.Text == "")
          {
              Label2.Text = "Write Name...!";
              return;
          }

          if (txtadd1.Text == "")
          {
              Label2.Text = "Write Address...!";
              return;
          }

          if (txtadd2.Text == "")
          {
              Label2.Text = "Write Address...!";
              return;
          }

          if (txtadd3.Text == "")
          {
              Label2.Text = "Write Address...!";
              return;
          }

          if (txtadd4.Text == "")
          {
              Label2.Text = "Write Address...!";
              return;
          }

          if (txtdistrict1.Text == "")
          {
              Label2.Text = "Select District...!";
              return;
          }

          if (txtstate1.Text == "")
          {
              Label2.Text = "Select State...!";
              return;
          }

          if (txtphone1.Text == "")
          {
              Label2.Text = "Phone No. error...!";
              return;
          }

          if (txtmobile11.Text == "")
          {
              Label2.Text = "Mobile No. ...!";
              return;
          }

          if (ddmodel1.SelectedItem.ToString() == "select")
          {
              Label2.Text = "Select Model...!";
              return;
          }

          if (txtchassis.Text == "")
          {
              Label2.Text = "Write Chassis No. ...!";
              return;
          }

          if (txtengg.Text == "")
          {
              Label2.Text = "Write Engine no. ...!";
              return;
          }

          if (txtyear.Text == "select")
          {
              Label2.Text = "Select Year";
              return;
          }

          if (txtreg.Text == "")
          {
              Label2.Text = "Write Registration no. ...!";
              return;
          }

          if (txtcolor.Text == "")
          {
              Label2.Text = "Write Color...!";
              return;
          }

          if (txtkey.Text == "")
          {
              Label2.Text = "Write Key No. ...!";
              return;
          }

          if (txtbook.Text == "")
          {
              Label2.Text = "Select Service Book...!";
              return;
          }

          if (battery.Text == "")
          {
              Label2.Text = "Write Battery No. ...!";
              return;
          }

          if (txtprice.Text == "")
          {
              Label2.Text = "Write Price...!";
              return;
          }

          if (txtgst.Text == "")
          {
              Label2.Text = "GST %...!";
              return;
          }

          if (txtrate.Text == "")
          {
              Label2.Text = "Rate...!";
              return;
          }

          if (txtins.Text == "")
          {
              Label2.Text = "Insurance...!";
              return;
          }

          if (txttotal.Text == "")
          {
              Label2.Text = "Total...!";
              return;
          }

          if (txtadv.Text == "")
          {
              Label2.Text = "Advance...!";
              return;
          }

          if (txtnet.Text== "")
          {
              Label2.Text = "Net Ammount...!";
              return;
          }

          if (txtmode.Text == "")
          {
              Label2.Text = "Paymode...!";
              return;
          }

          if (txtacc.Text == "")
          {
              Label2.Text = "Account no. ...!";
              return;
          }

          if (txtcheck.Text == "")
          {
              Label2.Text = "Check no. ...!";
              return;
          }

          if (txttprice.Text == "")
          {
              Label2.Text = "Price...!";
              return;
          }
          if (txtamcust.Text == "")
          {
              Label2.Text = "Amount by customer...!";
              return;
          }

          if (txtdue.Text == "")
          {
              Label2.Text = "Dur amount...!";
              return;
          }*/


        string sale_by = null;
        string sale_type = null;
        string model = null;
        sale_by = ddagent_name.SelectedItem.ToString();
        sale_type = ddsale_type.SelectedItem.ToString();
        model = ddmodel1.SelectedItem.ToString();
        try
        {
            SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["hero_connect"].ConnectionString);
            SqlDataAdapter da = new SqlDataAdapter("select * from TINVOICE where Chassisno = ' " + txtchassis.Text + " ' ", con);
            DataSet ds = new DataSet();
            da.Fill(ds);
            if (ds.Tables[0].Rows.Count == 0)
            {
                // SqlCommand cmd = new SqlCommand("insert into TINVOICE(Dat, Mechanic, Saleby, Saletype, Bank, Remark, Pename, Peaddress1, Peaddress2, Peaddress3, Peaddress4, Pedistrict, Pestate, Peoff, Peres, Pemobile, Praddress1, Praddress2, Praddress3, Praddress4, Prdistrict, Prstate, Proff, Prres, Prmobile, Model, Chassisno, Engineno, Year, Regno, Color, Keyno, Serbook, Battery, Typef, Typer, Price, GST, Rate, Ins, Total, Adv, Net, Paymode, Acnt, Checkno, Dae, Grand, Paid, Due) values (@Dat, @Mechanic, @Saleby, @Saletype, @Bank, @Remark, @Pename, @Peaddress1, @Peaddress2, @Peaddress3, @Peaddress4, @Pedistrict, @Pestate, @Peoff, @Peres, @Pemobile, @Praddress1, @Praddress2, @Praddress3, @Praddress4, @Prdistrict, @Prstate, @Proff, @Prres, @Prmobile, @Model, @Chassisno, @Engineno, @Year, @Regno, @Color, @Keyno, @Serbook, @Battery, @Typef, @Typer, @Price, @GST, @Rate, @Ins, @Total, @Adv, @Net, @Paymode, @Acnt, @Checkno, @Dae, @Grand, @Paid, @Due)", con);

                SqlCommand cmd = new SqlCommand("insert into TINVOICE(Dat, Mechanic, Saleby, Saletype, Bank, Remark, Pename, Peaddress1, Peaddress2, Peaddress3, Peaddress4, Pedistrict, Pestate, Peoff, Peres, Pemobile, Praddress1, Praddress2, Praddress3, Praddress4, Prdistrict, Prstate, Proff, Prres, Prmobile, Model, Chassisno, Engineno, Year, Regno, Color, Keyno, Serbook, Battery, Typef, Typer, Price, GST, Rate, Ins, Total, Adv, Net, Paymode, Acnt, Checkno, Dae, Grand, Paid, Due) values (@Dat, @Mechanic, @Saleby, @Saletype, @Bank, @Remark, @Pename, @Peaddress1, @Peaddress2, @Peaddress3, @Peaddress4, @Pedistrict, @Pestate, @Peoff, @Peres, @Pemobile, @Praddress1, @Praddress2, @Praddress3, @Praddress4, @Prdistrict, @Prstate, @Proff, @Prres, @Prmobile, @Model, @Chassisno, @Engineno, @Year, @Regno, @Color, @Keyno, @Serbook, @Battery, @Typef, @Typer, @Price, @GST, @Rate, @Ins, @Total, @Adv, @Net, @Paymode, @Acnt, @Checkno, @Dae, @Grand, @Paid, @Due)", con);

                cmd.Parameters.Add("@Dat", SqlDbType.DateTime).Value = Convert.ToDateTime(txtdate.Text);
                cmd.Parameters.Add("@Mechanic", SqlDbType.VarChar).Value = txtmechanic.Text.ToUpper();
                cmd.Parameters.Add("@Saleby", SqlDbType.VarChar).Value = sale_by;
                cmd.Parameters.Add("@Saletype", SqlDbType.VarChar).Value = sale_type;
                cmd.Parameters.Add("@Bank", SqlDbType.VarChar).Value = txtbank.Text;
                cmd.Parameters.Add("@Remark", SqlDbType.VarChar).Value = txtremark.Text;
                cmd.Parameters.Add("@Pename", SqlDbType.VarChar).Value = txtname.Text.ToUpper();
                cmd.Parameters.Add("@Peaddress1", SqlDbType.VarChar).Value = txtadd1.Text.ToUpper();
                cmd.Parameters.Add("@Peaddress2", SqlDbType.VarChar).Value = txtadd2.Text.ToUpper();
                cmd.Parameters.Add("@Peaddress3", SqlDbType.VarChar).Value = txtadd3.Text.ToUpper();
                cmd.Parameters.Add("@Peaddress4", SqlDbType.VarChar).Value = txtadd4.Text.ToUpper();
                cmd.Parameters.Add("@Pedistrict", SqlDbType.VarChar).Value = txtdistrict1.Text.ToUpper();
                cmd.Parameters.Add("@Pestate", SqlDbType.VarChar).Value = txtstate1.Text.ToUpper();
                cmd.Parameters.Add("@Peoff", SqlDbType.VarChar).Value = txtphone1.Text.ToUpper();
                cmd.Parameters.Add("@Peres", SqlDbType.VarChar).Value = txtp33.Text.ToUpper();
                cmd.Parameters.Add("@Pemobile", SqlDbType.VarChar).Value = txtmobile11.Text;
                cmd.Parameters.Add("@Model", SqlDbType.VarChar).Value = model;
                cmd.Parameters.Add("@Praddress1", SqlDbType.VarChar).Value = txtadd11.Text.ToUpper();
                cmd.Parameters.Add("@Praddress2", SqlDbType.VarChar).Value = txtadd22.Text.ToUpper();
                cmd.Parameters.Add("@Praddress3", SqlDbType.VarChar).Value = txtadd33.Text.ToUpper();
                cmd.Parameters.Add("@Praddress4", SqlDbType.VarChar).Value = txtadd44.Text.ToUpper();
                cmd.Parameters.Add("@Prdistrict", SqlDbType.VarChar).Value = txtdistrict11.Text.ToUpper();
                cmd.Parameters.Add("@Prstate", SqlDbType.VarChar).Value = txtstate11.Text.ToUpper();
                cmd.Parameters.Add("@Proff", SqlDbType.VarChar).Value = txtphone11.Text.ToUpper();
                cmd.Parameters.Add("@Prres", SqlDbType.VarChar).Value = txtp44.Text.ToUpper();
                cmd.Parameters.Add("@Prmobile", SqlDbType.VarChar).Value = txtmobile22.Text;

                cmd.Parameters.Add("@Chassisno", SqlDbType.VarChar).Value = txtchassis.Text;
                cmd.Parameters.Add("@Engineno", SqlDbType.VarChar).Value = txtengg.Text;
                cmd.Parameters.Add("@Year", SqlDbType.VarChar).Value = txtyear.Text;
                cmd.Parameters.Add("@Regno", SqlDbType.VarChar).Value = txtreg.Text;
                cmd.Parameters.Add("@Color", SqlDbType.VarChar).Value = txtcolor.Text;
                cmd.Parameters.Add("@Keyno", SqlDbType.VarChar).Value = txtkey.Text;
                cmd.Parameters.Add("@Serbook", SqlDbType.VarChar).Value = txtbook.Text;
                cmd.Parameters.Add("@Battery", SqlDbType.VarChar).Value = battery.Text;
                cmd.Parameters.Add("@Typef", SqlDbType.VarChar).Value = txttypef.Text;
                cmd.Parameters.Add("@Typer", SqlDbType.VarChar).Value = txttyper.Text;
                cmd.Parameters.Add("@Price", SqlDbType.VarChar).Value = txtprice.Text;
                cmd.Parameters.Add("@GST", SqlDbType.VarChar).Value = txtgst.Text;
                cmd.Parameters.Add("@Rate", SqlDbType.VarChar).Value = txtrate.Text;
                cmd.Parameters.Add("@Ins", SqlDbType.VarChar).Value = txtins.Text;
                cmd.Parameters.Add("@Total", SqlDbType.VarChar).Value = txttotal.Text;
                cmd.Parameters.Add("@Adv", SqlDbType.VarChar).Value = txtadv.Text;
                cmd.Parameters.Add("@Net", SqlDbType.VarChar).Value = txtnet.Text;
                cmd.Parameters.Add("@Paymode", SqlDbType.VarChar).Value = txtmode.Text;
                cmd.Parameters.Add("@Acnt", SqlDbType.VarChar).Value = txtacc.Text;
                cmd.Parameters.Add("@Checkno", SqlDbType.VarChar).Value = txtcheck.Text;
                cmd.Parameters.Add("@Dae", SqlDbType.DateTime).Value = Convert.ToDateTime(txtindate.Text);
                cmd.Parameters.Add("@Grand", SqlDbType.VarChar).Value = txttprice.Text;
                cmd.Parameters.Add("@Paid", SqlDbType.VarChar).Value = txtamcust.Text;
                cmd.Parameters.Add("@Due", SqlDbType.VarChar).Value = txtdue.Text;



                con.Open();
                cmd.ExecuteNonQuery();
                con.Close();
                Label2.Text = "Data Inserted successfully...";
            }
            else
            {
                Label2.Text = "Data alredy exists...";
            }
        }
        catch (Exception ex)
        {
            Response.Write(ex.Message.ToString());
        }
    }
    protected void ddsameaddress_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (ddsameaddress.SelectedItem.ToString() == "same")
        {
            txtadd11.Text = txtadd1.Text;
            txtadd22.Text = txtadd2.Text;
            txtadd33.Text = txtadd3.Text;
            txtadd44.Text = txtadd4.Text;
            txtdistrict11.Text = txtdistrict1.Text;
            txtstate11.Text = txtstate1.Text;
        }

        else
        {
            txtadd11.Text = "";
            txtadd22.Text = "";
            txtadd33.Text = "";
            txtadd44.Text = "";
            txtdistrict11.Text = "";
            txtstate11.Text = "";
        }

    }
}