﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

public partial class update_password : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }



    protected void updatebt_Click(object sender, EventArgs e)
    {
        if (txtUpdate_Uname.Text == "")
        {
            notice.Text = "Enter User Name...";
            return;
        }

        if (txtupdate_Npassword.Text == "")
        {
            notice.Text = "Enter New Password...";
            return;
        }

        if (txtupdate_cnpassword.Text == "")
        {
            notice.Text = "Enter Confirm Password...";
            return;
        }

        if (txtupdate_oldpassword.Text == "")
        {
            notice.Text = "Enter Old Password...";
            return;
        }
        try
        {
            SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["hero_connect"].ConnectionString);
            SqlDataAdapter da = new SqlDataAdapter("select * from Client where Uname = '" +txtUpdate_Uname.Text+ "' ", con);
            DataSet ds = new DataSet();
            da.Fill(ds);
            if (ds.Tables[0].Rows.Count == 1)
            {
                SqlCommand cmd = new SqlCommand("update Client set password = '" + txtupdate_Npassword.Text + "' where password = '" + txtupdate_oldpassword.Text + "' ", con);
                
                con.Open();
                cmd.ExecuteNonQuery();
                con.Close();
                string msg1 = "alert('Password Change Successfully...!!!');";
                ScriptManager.RegisterStartupScript(this, this.GetType(), "msg1", msg1, true);
            }

            else
            {
                string msg1 = "alert('Unable to change Password...!!!');";
                ScriptManager.RegisterStartupScript(this, this.GetType(), "msg1", msg1, true);
            }
        }

        catch (Exception ex)
        {
            Response.Write(ex.Message.ToString());
        }
        
    }




    protected void resetbt_Click(object sender, EventArgs e)
    {
        txtUpdate_Uname.Text = "";
        txtupdate_Npassword.Text = "";
        txtupdate_cnpassword.Text = "";
        txtupdate_oldpassword.Text = "";
    }
}