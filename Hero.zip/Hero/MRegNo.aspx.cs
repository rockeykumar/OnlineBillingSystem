﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;


public partial class MRegNo : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void btsub_Click1(object sender, EventArgs e)
    {
        if (TextBox1.Text == "")
        {
            string msg1 = "alert('Enter serial no. ...!!!');";
            ScriptManager.RegisterStartupScript(this, this.GetType(), "msg1", msg1, true);
            return;
        }

        if (TextBox2.Text == "")
        {
            string msg1 = "alert('Enter serial no. within group ...!!!');";
            ScriptManager.RegisterStartupScript(this, this.GetType(), "msg1", msg1, true);
            return;
        }

        if (TextBox3.Text == "")
        {
            string msg1 = "alert('Enter reference no. ...!!!');";
            ScriptManager.RegisterStartupScript(this, this.GetType(), "msg1", msg1, true);
            return;
        }

        if (TextBox4.Text == "")
        {
            string msg1 = "alert('Enter registration no. ...!!!');";
            ScriptManager.RegisterStartupScript(this, this.GetType(), "msg1", msg1, true);
            return;
        }

        if (TextBox5.Text == "")
        {
            string msg1 = "alert('Enter Bill no. ...!!!');";
            ScriptManager.RegisterStartupScript(this, this.GetType(), "msg1", msg1, true);
            return;
        }

        try
        {
            SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["hero_connect"].ConnectionString);
            SqlDataAdapter da = new SqlDataAdapter("select * from MRegNo where S_no = '" + TextBox1.Text + "'", con);
            DataSet ds = new DataSet();
            da.Fill(ds);
            if (ds.Tables[0].Rows.Count == 0)
            {
                SqlCommand cmd = new SqlCommand("insert into MRegNo(S_no, Si_no, Ref_no, Reg_no, Bill_no) values (@S_no, @Si_no, @Ref_no, @Reg_no, @Bill_no)", con);

                cmd.Parameters.Add("@S_no", SqlDbType.VarChar).Value = TextBox1.Text;
                cmd.Parameters.Add("@Si_no", SqlDbType.VarChar).Value = TextBox2.Text;
                cmd.Parameters.Add("@Ref_no", SqlDbType.VarChar).Value = TextBox3.Text;
                cmd.Parameters.Add("@Reg_no", SqlDbType.VarChar).Value = TextBox4.Text;
                cmd.Parameters.Add("@Bill_no", SqlDbType.VarChar).Value = TextBox5.Text;

                con.Open();
                cmd.ExecuteNonQuery();
                con.Close();
                string msg1 = "alert('Submit Successfully...!!!');";
                ScriptManager.RegisterStartupScript(this, this.GetType(), "msg1", msg1, true);
                // Response.Redirect("index_user.aspx");
            }
            else
            {
                string msg1 = "alert('Already Submited...!!!');";
                ScriptManager.RegisterStartupScript(this, this.GetType(), "msg1", msg1, true);
            }
        }
        catch (Exception ex)
        {
            Response.Write(ex.Message.ToString());
        }
    }
}