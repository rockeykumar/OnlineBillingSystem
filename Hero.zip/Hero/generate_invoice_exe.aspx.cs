﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
public partial class generate_invoice_exe : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        bind();
    }

    protected void bind()
    {

        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["hero_connect"].ConnectionString);
        SqlDataAdapter da = new SqlDataAdapter("select Invoice, Dat, Mechanic, Saleby, Prmobile, Model, Chassisno, Engineno, Color, Serbook, Battery, Price, GST, Total, Paymode, Acnt, Paid, Due from TINVOICE ", con);
        DataSet ds = new DataSet();
        da.Fill(ds);
        if (ds.Tables[0].Rows.Count > 0)
        {
            GridView1.DataSource = ds.Tables[0];
            GridView1.DataBind();

        }
    }

    protected void GridView1_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        GridView1.PageIndex = e.NewPageIndex;
        bind();
    }


    protected void ddinvoice_no_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
    protected void txtgeninv_TextChanged(object sender, EventArgs e)
    {


    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        if (txtgeninv.Text == "")
        {
            string msg1 = "alert('Select Invoice Date...!!!');";
            ScriptManager.RegisterStartupScript(this, this.GetType(), "msg1", msg1, true);
            return;
        }

        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["hero_connect"].ConnectionString);
        SqlDataAdapter da = new SqlDataAdapter("select distinct(Invoice) as tinv from TINVOICE where Dat ='" + Convert.ToDateTime(txtgeninv.Text) + "' ", con);
        DataSet ds = new DataSet();
        da.Fill(ds);
        if (ds.Tables[0].Rows.Count > 0)
        {
            ddinvoice_no.DataSource = ds.Tables[0];
            ddinvoice_no.DataTextField = ds.Tables[0].Columns["tinv"].ToString();
            ddinvoice_no.DataValueField = ds.Tables[0].Columns["tinv"].ToString();
            ddinvoice_no.DataBind();
            ddinvoice_no.Items.Insert(0, "Select");
        }
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        if (ddinvoice_no.SelectedValue == "")
        {
            string msg1 = "alert('Please select Date of Invoice...!!!');";
            ScriptManager.RegisterStartupScript(this, this.GetType(), "msg1", msg1, true);
            return;
        }

        if (ddinvoice_no.SelectedValue == "Select")
        {
            string msg1 = "alert('Please select Invoice Number...!!!');";
            ScriptManager.RegisterStartupScript(this, this.GetType(), "msg1", msg1, true);
            return;
        }
        Response.Redirect("printInvoice.aspx?INV=" + ddinvoice_no.SelectedItem.ToString());

    }
}