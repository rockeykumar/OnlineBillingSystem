﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

public partial class purchase_motor_bike : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["hero_connect"].ConnectionString);
            SqlDataAdapter da = new SqlDataAdapter("select  Supp_name from MSupplier order by Supp_name  ", con);
            DataSet ds = new DataSet();
            da.Fill(ds);
            if (ds.Tables[0].Rows.Count > 0)
            {
                DropDownList1.DataSource = ds.Tables[0];
                DropDownList1.DataTextField = ds.Tables[0].Columns["Supp_name"].ToString();
                DropDownList1.DataValueField = ds.Tables[0].Columns["Supp_name"].ToString();
                DropDownList1.DataBind();
                DropDownList1.Items.Insert(0, "Select");
            }

        }
        
    }
    protected void txtdate_TextChanged(object sender, EventArgs e)
    {

    }
    protected void TextBox2_TextChanged(object sender, EventArgs e)
    {

    }
    protected void ddinvoice_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
    protected void txtinvoicedate_TextChanged(object sender, EventArgs e)
    {

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        string supp_name = null;
        string invoice_no = null;
        string tax = null;
        string no_of_bile = null;
        supp_name = DropDownList1.SelectedItem.ToString();
        invoice_no = ddinvoice.SelectedItem.ToString();
        tax = DropDownList2.SelectedItem.ToString();
        no_of_bile = DropDownList3.SelectedItem.ToString();
        try
        {
            SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["hero_connect"].ConnectionString);
            SqlDataAdapter da = new SqlDataAdapter("select * from TPRODUCT where Chassis_no = '" + txtc.Text + "' ", con);
            DataSet ds = new DataSet();
            da.Fill(ds);
            if (ds.Tables[0].Rows.Count == 0)
            {
                SqlCommand cmd = new SqlCommand("insert into TPRODUCT(V_no, Dat, Invoice, Name, Address, City, Model, Chassis_no, Engine_no, Color, Key_no, Rate, N_o_b, Inv_tot) values (@V_no, @Dat, @Invoice, @Name, @Address, @City, @Model, @Chassis_no, @Engine_no, @Color, @Key_no, @Rate, @N_o_b, @Inv_tot)", con);

                cmd.Parameters.Add("@V_no", SqlDbType.VarChar).Value = txtv.Text;
                cmd.Parameters.Add("@Dat", SqlDbType.DateTime).Value = Convert.ToString( txtdate.Text);
                cmd.Parameters.Add("@Name", SqlDbType.VarChar).Value = supp_name;
                cmd.Parameters.Add("@Address", SqlDbType.VarChar).Value = TextBox2.Text;
                cmd.Parameters.Add("@City", SqlDbType.VarChar).Value = txtadd.Text;
                cmd.Parameters.Add("@Model", SqlDbType.VarChar).Value = txtm.Text;
                cmd.Parameters.Add("@Chassis_no", SqlDbType.VarChar).Value = txtc.Text;
                cmd.Parameters.Add("@Engine_no", SqlDbType.VarChar).Value = txte.Text;
                cmd.Parameters.Add("@Color", SqlDbType.VarChar).Value = txtclo.Text;
                cmd.Parameters.Add("@Key_no", SqlDbType.VarChar).Value = txtk.Text;
                cmd.Parameters.Add("@Invoice", SqlDbType.VarChar).Value = invoice_no;
                cmd.Parameters.Add("@Rate", SqlDbType.VarChar).Value = txtr.Text;
                cmd.Parameters.Add("@N_o_b", SqlDbType.VarChar).Value = no_of_bile;
                cmd.Parameters.Add("@Inv_tot", SqlDbType.VarChar).Value = txttotalcost.Text;

                con.Open();
                cmd.ExecuteNonQuery();
                con.Close();
                llbb.Text = "Data recoreded...";
            }
            else
            {
                llbb.Text = "data allready exist...";
            }
        }
        catch (Exception ex)
        {
            Response.Write(ex.Message.ToString());
        }
    }
    
    
    protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["hero_connect"].ConnectionString);
            SqlDataAdapter da = new SqlDataAdapter("select * from MSupplier where Supp_name ='" + DropDownList1.SelectedItem.ToString() + "' ", con);
            DataSet ds = new DataSet();
            da.Fill(ds);
            if (ds.Tables[0].Rows.Count > 0)
            {
                TextBox2.Text = ds.Tables[0].Rows[0]["Supp_add"].ToString();
            }
        }

        catch (Exception ex)
        {
            Response.Write(ex.Message.ToString());
        }

    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        string invoice_no = null;
        invoice_no = ddinvoice.SelectedItem.ToString();

        try
        {
            SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["hero_connect"].ConnectionString);
            SqlDataAdapter da = new SqlDataAdapter("select * from TPRODUCT where Invoice='"+invoice_no+ "' ", con);
            DataSet ds = new DataSet();
            da.Fill(ds);
            if (ds.Tables[0].Rows.Count == 1)
            {
                SqlCommand cmd = new SqlCommand("update TPRODUCT set V_no='" + txtv.Text + "', Dat='" + txtdate.Text + "', Model='" + txtm.Text + "', Chassis_no='" + txtc.Text + "', Engine_no='" + txte.Text + "', Color='" + txtclo.Text + "', Key_no='" + txtk.Text + "', Rate='" + txtr.Text + "', Inv_tot=" + txttotalcost.Text + " where Invoice='" + invoice_no + "' ", con);

                con.Open();
                cmd.ExecuteNonQuery();
                con.Close();
                llbb.Text = "Data Update Successfully...";
            }

            else
            {
                llbb.Text = "Enable To Update Password...";
            }
        }

        catch (Exception ex)
        {
            Response.Write(ex.Message.ToString());
        }
        
    }
}