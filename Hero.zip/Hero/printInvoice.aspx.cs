﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

public partial class printInvoice : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            try
            {
                SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["hero_connect"].ConnectionString);
                SqlDataAdapter da = new SqlDataAdapter("select *  from TINVOICE where Invoice='" + Request.QueryString["INV"].ToString() + "'", con);
                DataSet ds = new DataSet();
                da.Fill(ds);
                if (ds.Tables[0].Rows.Count > 0)
                {
                    td_customer.InnerHtml = ds.Tables[0].Rows[0]["Pename"].ToString();
                    td_inv_no.InnerHtml = ds.Tables[0].Rows[0]["Invoice"].ToString();
                    td_dat.InnerHtml = ds.Tables[0].Rows[0]["Dat"].ToString();
                    td_mechanic.InnerHtml = ds.Tables[0].Rows[0]["Mechanic"].ToString();
                    td_saleby.InnerHtml = ds.Tables[0].Rows[0]["Saleby"].ToString();
                    td_mob.InnerHtml = ds.Tables[0].Rows[0]["Pemobile"].ToString();
                    td_model.InnerHtml = ds.Tables[0].Rows[0]["Model"].ToString();
                    td_chassis.InnerHtml = ds.Tables[0].Rows[0]["Chassisno"].ToString();
                    td_eng.InnerHtml = ds.Tables[0].Rows[0]["Engineno"].ToString();
                    td_color.InnerHtml = ds.Tables[0].Rows[0]["Color"].ToString();
                    td_book.InnerHtml = ds.Tables[0].Rows[0]["Serbook"].ToString();
                    td_btty.InnerHtml = ds.Tables[0].Rows[0]["Battery"].ToString();
                    td_price.InnerHtml = ds.Tables[0].Rows[0]["Price"].ToString();
                    td_gst.InnerHtml = ds.Tables[0].Rows[0]["GST"].ToString();
                    td_Total.InnerHtml = ds.Tables[0].Rows[0]["Total"].ToString();
                    td_Acnt.InnerHtml = ds.Tables[0].Rows[0]["Acnt"].ToString();
                    td_Paymode.InnerHtml = ds.Tables[0].Rows[0]["Paymode"].ToString();
                    td_Paid.InnerHtml = ds.Tables[0].Rows[0]["Paid"].ToString();
                    td_Due.InnerHtml = ds.Tables[0].Rows[0]["Due"].ToString();
                }
            }
            catch (Exception ex)
            {
                Response.Write(ex.Message.ToString());
            }
        }
    }
    protected void btnclose_Click(object sender, EventArgs e)
    {

    }
    protected void btn_Printpermit_Click(object sender, EventArgs e)
    {

    }
}