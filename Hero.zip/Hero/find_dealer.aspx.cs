﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;


public partial class find_dealer : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        ddname.Enabled = false;
        dddistrict.Enabled = false;
        if (rd1.Checked == true)
        {
            ddname.Enabled = false;
            dddistrict.Enabled = true;
        }

        if (rd2.Checked == true)
        {
            dddistrict.Enabled = false;
            ddname.Enabled = true;

        }

    }
    
    protected void btSearch_Click1(object sender, EventArgs e)
    {
        if (rd1.Checked == true)
        {
            try
            {
                    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["hero_connect"].ConnectionString);
                    SqlDataAdapter da = new SqlDataAdapter("select * from MSupplier where District='"+dddistrict.SelectedItem.ToString()+"' ", con);
                    DataSet ds = new DataSet();
                    da.Fill(ds);
                    if (ds.Tables[0].Rows.Count > 0)
                    {
                        GridView1.DataSource=ds.Tables[0];
                        GridView1.DataBind();
                    }

                }
            
            catch (Exception ex)
            {
                Response.Write(ex.Message.ToString());
            } 
        }
        else if (rd2.Checked == true)
        {
            try
            {
                SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["hero_connect"].ConnectionString);
                SqlDataAdapter da = new SqlDataAdapter("select * from MSupplier where Supp_name='" + ddname.SelectedItem.ToString() + "' ", con);
                DataSet ds = new DataSet();
                da.Fill(ds);
                if (ds.Tables[0].Rows.Count > 0)
                {
                    GridView1.DataSource = ds.Tables[0];
                    GridView1.DataBind();
                }

            }

            catch (Exception ex)
            {
                Response.Write(ex.Message.ToString());
            } 
        }
    }
    protected void rd1_CheckedChanged(object sender, EventArgs e)
    {
        try
        {
            if (rd1.Checked == true)
            {

            SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["hero_connect"].ConnectionString);
            SqlDataAdapter da = new SqlDataAdapter("select distinct(District) as dist from MSupplier  ", con);
            DataSet ds = new DataSet();
            da.Fill(ds);
            if (ds.Tables[0].Rows.Count > 0)
            {
                dddistrict.DataSource=ds.Tables[0];
                dddistrict.DataTextField=ds.Tables[0].Columns["dist"].ToString();
                dddistrict.DataValueField=ds.Tables[0].Columns["dist"].ToString();
                dddistrict.DataBind();
                dddistrict.Items.Insert(0, "Select");
            }
            
            }
        }
        catch (Exception ex)
        {
            Response.Write(ex.Message.ToString());
        }
    }
    protected void rd2_CheckedChanged(object sender, EventArgs e)
    {
        try
        {
            if (rd2.Checked == true)
            {

                SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["hero_connect"].ConnectionString);
                SqlDataAdapter da = new SqlDataAdapter("select  Supp_name from MSupplier order by Supp_name  ", con);
                DataSet ds = new DataSet();
                da.Fill(ds);
                if (ds.Tables[0].Rows.Count > 0)
                {
                    ddname.DataSource = ds.Tables[0];
                    ddname.DataTextField = ds.Tables[0].Columns["Supp_name"].ToString();
                    ddname.DataValueField = ds.Tables[0].Columns["Supp_name"].ToString();
                    ddname.DataBind();
                    ddname.Items.Insert(0, "Select");
                }

            }
        }
        catch (Exception ex)
        {
            Response.Write(ex.Message.ToString());
        }
    }
    protected void dddistrict_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
    protected void ddname_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
}