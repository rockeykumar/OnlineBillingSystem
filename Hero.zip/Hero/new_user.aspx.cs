﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;


public partial class new_user : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
   
    protected void Button1_Click(object sender, EventArgs e)
    {
        string gender = null;
        if (RadioButton3.Checked == true)
        {
            gender = "Male";
        }
        else
        {
            gender = "Female";
        }

        if (txtFname.Text == "")
        {
            lable13.Text = "Enter First Name...";
            return;
        }

        if (txtLname.Text == "")
        {
            lable13.Text = "Enter Last Name... ";
            return;
        }

        if (txtUname.Text == "")
        {
            lable13.Text = "Enter User Name...";
            return;
        }

        if (txtemail.Text == "")
        {
            lable13.Text = "Enter E-mail id... ";
            return;
        }

        if (txtpassword.Text == "")
        {
            lable13.Text = "Enter Password...";
            return;
        }

        if (txtcnfpassword.Text == "")
        {
            lable13.Text = "Enter Confirm Password... ";
        }

        if (txtmobile.Text == "")
        {
            lable13.Text = "Enter mobile no. ...";
            return;
        }

        if (txtpassword.Text != txtcnfpassword.Text)
        {
            lable13.Text = "password and confirm password do not matched";
            return;
        }

        string question = null;
        question = DropDownList1.SelectedItem.ToString();

        try
        {
            SqlConnection con_admin = new SqlConnection(ConfigurationManager.ConnectionStrings["hero_connect"].ConnectionString);
            SqlConnection con_exe = new SqlConnection(ConfigurationManager.ConnectionStrings["hero_connect"].ConnectionString);

            SqlDataAdapter da_admin = new SqlDataAdapter("select * from Admin where Uname = ' " + txtUname.Text + " ' ", con_admin);
            SqlDataAdapter da_exe = new SqlDataAdapter("select * from Admin where Uname = ' " + txtUname.Text + " ' ", con_exe);

            DataSet ds_admin = new DataSet();
            DataSet ds_exe = new DataSet();

            da_admin.Fill(ds_admin);
            da_exe.Fill(ds_exe);

            if (RadioButton5.Checked == true)
            {


                if (ds_admin.Tables[0].Rows.Count == 0)
                {
                    SqlCommand cmd_admin = new SqlCommand("insert into Admin(Fname, Lname, Uname, email, password, gender, mobile, question, answer) values (@Fname, @Lname, @Uname, @email, @password, @gender, @mobile, @question, @answer)", con_admin);

                    cmd_admin.Parameters.Add("@Fname", SqlDbType.VarChar).Value = txtFname.Text;
                    cmd_admin.Parameters.Add("@Lname", SqlDbType.VarChar).Value = txtLname.Text;
                    cmd_admin.Parameters.Add("@Uname", SqlDbType.VarChar).Value = txtUname.Text;
                    cmd_admin.Parameters.Add("@email", SqlDbType.VarChar).Value = txtemail.Text;
                    cmd_admin.Parameters.Add("@password", SqlDbType.VarChar).Value = txtpassword.Text;
                    cmd_admin.Parameters.Add("@mobile", SqlDbType.VarChar).Value = txtmobile.Text;
                    cmd_admin.Parameters.Add("@gender", SqlDbType.VarChar).Value = gender;
                    cmd_admin.Parameters.Add("@question", SqlDbType.VarChar).Value = question;
                    cmd_admin.Parameters.Add("@answer", SqlDbType.VarChar).Value = txtanswer.Text;

                    con_admin.Open();
                    cmd_admin.ExecuteNonQuery();
                    con_admin.Close();
                    lable13.Text = "Account Created Successfully...!";
                }
            }

            else if (RadioButton6.Checked == true)
            {

                if (ds_exe.Tables[0].Rows.Count == 0)
                {
                    SqlCommand cmd_exe = new SqlCommand("insert into Executive(Fname, Lname, Uname, email, password, gender, mobile, question, answer) values (@Fname, @Lname, @Uname, @email, @password, @gender, @mobile, @question, @answer)", con_exe);

                    cmd_exe.Parameters.Add("@Fname", SqlDbType.VarChar).Value = txtFname.Text;
                    cmd_exe.Parameters.Add("@Lname", SqlDbType.VarChar).Value = txtLname.Text;
                    cmd_exe.Parameters.Add("@Uname", SqlDbType.VarChar).Value = txtUname.Text;
                    cmd_exe.Parameters.Add("@email", SqlDbType.VarChar).Value = txtemail.Text;
                    cmd_exe.Parameters.Add("@password", SqlDbType.VarChar).Value = txtpassword.Text;
                    cmd_exe.Parameters.Add("@mobile", SqlDbType.VarChar).Value = txtmobile.Text;
                    cmd_exe.Parameters.Add("@gender", SqlDbType.VarChar).Value = gender;
                    cmd_exe.Parameters.Add("@question", SqlDbType.VarChar).Value = question;
                    cmd_exe.Parameters.Add("@answer", SqlDbType.VarChar).Value = txtanswer.Text;

                    con_exe.Open();
                    cmd_exe.ExecuteNonQuery();
                    con_exe.Close();
                    lable13.Text = "Account Created Successfully...!";
                }
            }


            //else if ( )
            //{

           // }



            else
            {
                lable13.Text = "Account alredy exists...";
            }
        }
        catch (Exception ex)
        {
            Response.Write(ex.Message.ToString());
        }
    }
    protected void RadioButton3_CheckedChanged(object sender, EventArgs e)
    {

    }
    protected void RadioButton4_CheckedChanged(object sender, EventArgs e)
    {

    }
    protected void RadioButton1_CheckedChanged(object sender, EventArgs e)
    {

    }
    protected void RadioButton2_CheckedChanged(object sender, EventArgs e)
    {

    }
}