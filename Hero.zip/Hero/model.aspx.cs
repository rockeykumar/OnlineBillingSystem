﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

public partial class model : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void insert_Click(object sender, EventArgs e)
    {
        if (txtsno.Text == "")
        {
            lbans.Text = "Enter Serial No...";
            return;
        }
        if (txtmodel.Text == "")
        {
            lbans.Text = "Enter Supplier Name...";
            return;
        }

        if (txtgroup.Text == "")
        {
            lbans.Text = "Enter Supplier Address...";
            return;
        }

        if (txttovhl.Text == "")
        {
            lbans.Text = "Enter District Name...";
            return;
        }

        if (txtcovh.Text == "")
        {
            lbans.Text = "Enter State Name...";
            return;
        }

        if (txtcompanyname.Text == "")
        {
            lbans.Text = "Enter Mobile No...";
            return;
        }

        if (txtfuel.Text == "")
        {
            lbans.Text = "Enter Mobile No...";
            return;
        }

        if (txtcylinder.Text == "")
        {
            lbans.Text = "Enter Mobile No...";
            return;
        }

        if (txtseat.Text == "")
        {
            lbans.Text = "Enter Mobile No...";
            return;
        }

        if (txtweight.Text == "")
        {
            lbans.Text = "Enter Mobile No...";
            return;
        }

        if (txtbodytype.Text == "")
        {
            lbans.Text = "Enter Mobile No...";
            return;
        }

        if (txthpower.Text == "")
        {
            lbans.Text = "Enter Mobile No...";
            return;
        }

        if (txtPrate.Text == "")
        {
            lbans.Text = "Enter Mobile No...";
            return;
        }

        if (txtretailrate.Text == "")
        {
            lbans.Text = "Enter Mobile No...";
            return;
        }

        if (txtshowrate.Text == "")
        {
            lbans.Text = "Enter Mobile No...";
            return;
        }

        if (txtdiscount.Text == "")
        {
            lbans.Text = "Enter Mobile No...";
            return;
        }

        if (txtinsurance.Text == "")
        {
            lbans.Text = "Enter Mobile No...";
            return;
        }

        if (txtmrp.Text == "")
        {
            lbans.Text = "Enter Mobile No...";
            return;
        }

        try
        {
            SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["hero_connect"].ConnectionString);
            SqlDataAdapter da = new SqlDataAdapter("select * from BikeModel where S_no = " + txtsno.Text + " ", con);
            DataSet ds = new DataSet();
            da.Fill(ds);
            if (ds.Tables[0].Rows.Count == 0)
            {
                SqlCommand cmd = new SqlCommand("insert into BikeModel(S_no, Model, Gr, Type, Class, Maker, Fuel, N_o_c, Seat, K_weight, B_type, H_power, P_rate, R_rate, Sh_rate, Disc, Ins, Mrp) values (@S_no, @Model, @Gr, @Type, @Class, @Maker, @Fuel, @N_o_c, @Seat, @K_weight, @B_type, @H_power, @P_rate, @R_rate, @Sh_rate, @Disc, @Ins, @mrp)", con);

                cmd.Parameters.Add("@S_no", SqlDbType.Int).Value = txtsno.Text;
                cmd.Parameters.Add("@Model", SqlDbType.VarChar).Value = txtmodel.Text;
                cmd.Parameters.Add("@Gr", SqlDbType.VarChar).Value = txtgroup.Text;
                cmd.Parameters.Add("@Type", SqlDbType.VarChar).Value = txttovhl.Text;
                cmd.Parameters.Add("@Class", SqlDbType.VarChar).Value = txtcovh.Text;
                cmd.Parameters.Add("@Maker", SqlDbType.VarChar).Value = txtcompanyname.Text;
                cmd.Parameters.Add("@Fuel", SqlDbType.VarChar).Value = txtfuel.Text;
                cmd.Parameters.Add("@N_o_c", SqlDbType.VarChar).Value = txtcylinder.Text;
                cmd.Parameters.Add("@Seat", SqlDbType.VarChar).Value = txtseat.Text;
                cmd.Parameters.Add("@K_weight", SqlDbType.VarChar).Value = txtweight.Text;
                cmd.Parameters.Add("@B_type", SqlDbType.VarChar).Value = txtbodytype.Text;
                cmd.Parameters.Add("@H_power", SqlDbType.VarChar).Value = txthpower.Text;
                cmd.Parameters.Add("@P_rate", SqlDbType.VarChar).Value = txtPrate.Text;
                cmd.Parameters.Add("@R_rate", SqlDbType.VarChar).Value = txtretailrate.Text;
                cmd.Parameters.Add("@Sh_rate", SqlDbType.VarChar).Value = txtshowrate.Text;
                cmd.Parameters.Add("@Disc", SqlDbType.VarChar).Value = txtdiscount.Text;
                cmd.Parameters.Add("@Ins", SqlDbType.VarChar).Value = txtinsurance.Text;
                cmd.Parameters.Add("@mrp", SqlDbType.VarChar).Value = txtmrp.Text;

                con.Open();
                cmd.ExecuteNonQuery();
                con.Close();
                lbans.Text = "Data Inserted successfully...";
            }
        }
        catch (Exception ex)
        {
            Response.Write(ex.Message.ToString());
        }
    }
    protected void update_Click(object sender, EventArgs e)
    {
        if (txtsno.Text == "")
        {
            lbans.Text = "Enter Serial No...";
            return;
        }
        
        try
        {
            SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["hero_connect"].ConnectionString);
            SqlDataAdapter da = new SqlDataAdapter("select * from BikeModel where S_no = " + txtsno.Text + " ", con);
            DataSet ds = new DataSet();
            da.Fill(ds);
            if (ds.Tables[0].Rows.Count == 1)
            {
                 SqlCommand cmd = new SqlCommand("update BikeModel set Model ='"+txtmodel.Text+"', Gr='"+txtgroup.Text+"', Type='"+txttovhl.Text+"', Class='"+txtcovh.Text+"', Maker='"+txtcompanyname.Text+"', Fuel='"+txtfuel.Text+"', N_o_c="+txtcylinder.Text+", Seat="+txtseat.Text+", K_weight="+txtweight.Text+", B_type='"+txtbodytype.Text+"', H_power="+txthpower.Text+", P_rate="+txtPrate.Text+", R_rate="+txtretailrate.Text+", Sh_rate="+txtshowrate.Text+", Disc="+txtdiscount.Text+", Ins="+txtinsurance.Text+", Mrp="+txtmrp.Text+" where S_no = "+txtsno.Text+" ", con);

                con.Open();
                cmd.ExecuteNonQuery();
                con.Close();
                lbans.Text = "Data Update Successfully...";
            }

            else
            {
                lbans.Text = "Enable To Update Data...";
            }
        }

        catch (Exception ex)
        {
            Response.Write(ex.Message.ToString());
        }

    }
    protected void clear_Click(object sender, EventArgs e)
    {
        txtsno.Text = "";
        txtmodel.Text = "";
        txtgroup.Text = "";
        txttovhl.Text = "";
        txtcovh.Text = "";
        txtcompanyname.Text = "";
        txtfuel.Text = "";
        txtcylinder.Text = "";
        txtseat.Text = "";
        txtweight.Text = "";
        txtbodytype.Text = "";
        txthpower.Text = "";
        txtPrate.Text = "";
        txtretailrate.Text = "";
        txtshowrate.Text = "";
        txtdiscount.Text = "";
        txtinsurance.Text = "";
        txtmrp.Text = "";
    }
    protected void delect_Click(object sender, EventArgs e)
    {
        try
        {
            SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["hero_connect"].ConnectionString);
            SqlCommand cmd = new SqlCommand("delete from BikeModel where S_no ="+txtrecoreddelet.Text+" ", con);
            con.Open();
            cmd.ExecuteNonQuery();
            con.Close();
            lbans.Text = "Recored Deleted...";
        }

        catch (Exception ex)
        {
            Response.Write(ex.Message.ToString());
        }
    }
}