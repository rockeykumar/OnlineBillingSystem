﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

public partial class enquiry_exe : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        string gender = null;
        if (RadioButton1.Checked == true)
        {
            gender = "Male";
        }
        else
        {
            gender = "Female";
        }

        if (RadioButton1.Checked == false)
        {
            eqlb.Text = "Choose Gender...!";
            return;
        }

        if (txtFname.Text == "")
        {
            eqlb.Text = "Fill First Name...!";
            return;
        }

        if (txtLname.Text == "")
        {
            eqlb.Text = "Fill Last Name...!";
            return;
        }

        if (txtmobile.Text == "")
        {
            eqlb.Text = "Enter Mobile No. ...!";
            return;
        }

        if (txtemail.Text == "")
        {
            eqlb.Text = "Enter Email id...!";
            return;
        }

        if (ddmodel.SelectedItem.ToString() == "select")
        {
            eqlb.Text = "Choose Model...!";
            return;
        }

        if (txtstate.Text == "")
        {
            eqlb.Text = "Enter State Name...!";
            return;
        }

        if (txtdistrict.Text == "")
        {
            eqlb.Text = "Enter District...!";
            return;
        }

        if (txtcity.Text == "")
        {
            eqlb.Text = "Enter City...!";
            return;
        }

        if (txtdstate.Text == "")
        {
            eqlb.Text = "Enter Dealer State...!";
            return;
        }

        if (txtdtown.Text == "")
        {
            eqlb.Text = "Enter Dealer Town...!";
            return;
        }

        if (txtdealer.Text == "")
        {
            eqlb.Text = "Enter Dealer Name...!";
            return;
        }

        if (txtbrief.Text == "")
        {
            eqlb.Text = "Fill Brief About Enquiry...!";
            return;
        }

        if (txtdate.Text == "")
        {
            eqlb.Text = "Choose Date...!";
            return;
        }

        if (txtage.Text == "")
        {
            eqlb.Text = "Enter Age...!";
            return;
        }

        if (txtoccupation.Text == "")
        {
            eqlb.Text = "Enter Occupation...!";
            return;
        }

        string model = null;
        model = ddmodel.SelectedItem.ToString();

        try
        {
            SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["hero_connect"].ConnectionString);


            SqlCommand cmd = new SqlCommand("insert into Enquiry(Fname, Lname, Email, Mobile, Gender, Model, State, District, City, D_state, D_town, Dealer, Brief, Date, Age, Occupation) values (@Fname, @Lname, @Email, @Mobile, @Gender, @Model, @State, @District, @City, @D_state, @D_town, @Dealer, @Brief, @Date, @Age, @Occupation)", con);

            cmd.Parameters.Add("@Fname", SqlDbType.VarChar).Value = txtFname.Text;
            cmd.Parameters.Add("@Lname", SqlDbType.VarChar).Value = txtLname.Text;
            cmd.Parameters.Add("@email", SqlDbType.VarChar).Value = txtemail.Text;
            cmd.Parameters.Add("@State", SqlDbType.VarChar).Value = txtstate.Text;
            cmd.Parameters.Add("@mobile", SqlDbType.VarChar).Value = txtmobile.Text;
            cmd.Parameters.Add("@gender", SqlDbType.VarChar).Value = gender;
            cmd.Parameters.Add("@Model", SqlDbType.VarChar).Value = model;
            cmd.Parameters.Add("@District", SqlDbType.VarChar).Value = txtdistrict.Text;
            cmd.Parameters.Add("@City", SqlDbType.VarChar).Value = txtcity.Text;
            cmd.Parameters.Add("@D_state", SqlDbType.VarChar).Value = txtdstate.Text;
            cmd.Parameters.Add("@D_town", SqlDbType.VarChar).Value = txtdtown.Text;
            cmd.Parameters.Add("@Dealer", SqlDbType.VarChar).Value = txtdealer.Text;
            cmd.Parameters.Add("@Brief", SqlDbType.VarChar).Value = txtbrief.Text;
            cmd.Parameters.Add("@Date", SqlDbType.DateTime).Value = Convert.ToString(txtdate.Text);
            cmd.Parameters.Add("@Age", SqlDbType.VarChar).Value = txtage.Text;
            cmd.Parameters.Add("@Occupation", SqlDbType.VarChar).Value = txtoccupation.Text;

            con.Open();
            cmd.ExecuteNonQuery();
            con.Close();
            eqlb.Text = "successfully...!!!";
        }

        catch (Exception ex)
        {
            Response.Write(ex.Message.ToString());
        }
    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        txtFname.Text = "";
        txtLname.Text = "";
        txtmobile.Text = "";
        txtemail.Text = "";
        ddmodel.SelectedIndex = -1;
        txtstate.Text = "";
        txtdistrict.Text = "";
        txtcity.Text = "";
        txtdstate.Text = "";
        txtdtown.Text = "";
        txtdealer.Text = "";
        txtbrief.Text = "";
        txtdate.Text = "";
        RadioButton1.Checked = false;
        RadioButton2.Checked = false;
        txtage.Text = "";
        txtoccupation.Text = "";
    }
}