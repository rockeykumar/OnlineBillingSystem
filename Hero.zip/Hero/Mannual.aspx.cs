﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

public partial class Mannual : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void bt_mnul_Click(object sender, EventArgs e)
    {
        try
        {

            SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["hero_connect"].ConnectionString);
            SqlDataAdapter da = new SqlDataAdapter("select * from MMANUAL where Invoice = ' " + txt1.Text + " ' ", con);
            DataSet ds = new DataSet();
            da.Fill(ds);
            if (ds.Tables[0].Rows.Count == 0)
            {
                SqlCommand cmd = new SqlCommand("insert into MMANUAL(Invoice, Dat, Name, Address, City, GST, Model_name, Model_color, Chassis, Rate, Ammount, Qty, Invoice_total, Round, value_) values (@Invoice, @Dat, @Name, @Address, @City, @GST, @Model_name, @Model_color, @Chassis, @Rate, @Ammount, @Qty, @Invoice_total, @Round, @value_)", con);

                cmd.Parameters.Add("@Invoice", SqlDbType.VarChar).Value = txt1.Text;
                cmd.Parameters.Add("@Dat", SqlDbType.DateTime).Value = Convert.ToDateTime(date2.Text);
                cmd.Parameters.Add("@Name", SqlDbType.VarChar).Value = txt3.Text;
                cmd.Parameters.Add("@Address", SqlDbType.VarChar).Value = txtadd.Text;
                cmd.Parameters.Add("@City", SqlDbType.VarChar).Value = txt4.Text;
                cmd.Parameters.Add("@GST", SqlDbType.VarChar).Value = txt5.Text;
                cmd.Parameters.Add("@Model_name", SqlDbType.VarChar).Value = txt6.Text;
                cmd.Parameters.Add("@Model_color", SqlDbType.VarChar).Value = txt7.Text;
                cmd.Parameters.Add("@Chassis", SqlDbType.VarChar).Value = txt8.Text;
                cmd.Parameters.Add("@Rate", SqlDbType.VarChar).Value = txt9.Text;
                cmd.Parameters.Add("@Ammount", SqlDbType.VarChar).Value = txt10.Text;
                cmd.Parameters.Add("@Qty", SqlDbType.VarChar).Value = txt11.Text;
                cmd.Parameters.Add("@Invoice_total", SqlDbType.VarChar).Value = txt12.Text;
                cmd.Parameters.Add("@Round", SqlDbType.VarChar).Value = txt13.Text;
                cmd.Parameters.Add("@value_", SqlDbType.VarChar).Value = txt14.Text;

                con.Open();
                cmd.ExecuteNonQuery();
                con.Close();
                llbb.Text = "Data Inserted successfully...";
            }
            else
            {
                llbb.Text = "Data allready exists...";
            }
                       
        }
        catch (Exception ex)
        {
            Response.Write(ex.Message.ToString());
        }
    }
}