﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

public partial class sign_up : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        string gender = null;
        if (RadioButton1.Checked == true)
        {
            gender = "Male";
        }
        else
        {
            gender = "Female";
        }

        if (txtFname.Text == "")
        {
            //lable13.Text = "Enter First Name...";
            string msg1 = "alert('Enter First Name...!!!');";
            ScriptManager.RegisterStartupScript(this, this.GetType(), "msg1", msg1, true);
            return;
        }

        if (txtLname.Text == "")
        {
            //lable13.Text = "Enter Last Name... ";
            string msg1 = "alert('Enter Last Name...!!!');";
            ScriptManager.RegisterStartupScript(this, this.GetType(), "msg1", msg1, true);
            return;
        }

        if (txtUname.Text == "")
        {
            //lable13.Text = "Enter User Name...";
            string msg1 = "alert('Enter User Name...!!!');";
            ScriptManager.RegisterStartupScript(this, this.GetType(), "msg1", msg1, true);
            return;
        }

        if (txtemail.Text == "")
        {
            //lable13.Text = "Enter E-mail id... ";
            string msg1 = "alert('Enter E-mail id...!!!');";
            ScriptManager.RegisterStartupScript(this, this.GetType(), "msg1", msg1, true);
            return;
        }

        if (txtpassword.Text == "")
        {
            //lable13.Text = "Enter Password...";
            string msg1 = "alert('Enter Password...!!!');";
            ScriptManager.RegisterStartupScript(this, this.GetType(), "msg1", msg1, true);
            return;
        }

        if (txtcnfpassword.Text == "")
        {
            //lable13.Text = "Enter Confirm Password... ";
            string msg1 = "alert('Enter Confirm Password...!!!');";
            ScriptManager.RegisterStartupScript(this, this.GetType(), "msg1", msg1, true);
            return;
        }

        if (txtmobile.Text == "")
        {
            //lable13.Text = "Enter mobile no. ...";
            string msg1 = "alert('Enter Mobile no. ...!!!');";
            ScriptManager.RegisterStartupScript(this, this.GetType(), "msg1", msg1, true);
            return;
        }

        if (txtpassword.Text != txtcnfpassword.Text)
        {
            //lable13.Text = "password and confirm password do not matched";
            string msg1 = "alert('Password and Confirm Password do not matched ...!!!');";
            ScriptManager.RegisterStartupScript(this, this.GetType(), "msg1", msg1, true);
            return;
        }

        string question = null;
        question = DropDownList1.SelectedItem.ToString();

        try
        {
            SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["hero_connect"].ConnectionString);
            SqlDataAdapter da = new SqlDataAdapter("select * from Client where Uname = ' "+txtUname.Text+" ' ", con);
            DataSet ds = new DataSet();
            da.Fill(ds);
            if (ds.Tables[0].Rows.Count == 0)
            {
                SqlCommand cmd = new SqlCommand("insert into Client(Fname, Lname, Uname, email, password, gender, mobile, question, answer) values (@Fname, @Lname, @Uname, @email, @password, @gender, @mobile, @question, @answer)", con);
                
                cmd.Parameters.Add("@Fname", SqlDbType.VarChar).Value = txtFname.Text.ToUpper();
                cmd.Parameters.Add("@Lname", SqlDbType.VarChar).Value = txtLname.Text.ToUpper();
                cmd.Parameters.Add("@Uname", SqlDbType.VarChar).Value = txtUname.Text;
                cmd.Parameters.Add("@email", SqlDbType.VarChar).Value = txtemail.Text;
                cmd.Parameters.Add("@password", SqlDbType.VarChar).Value = txtpassword.Text;
                cmd.Parameters.Add("@mobile", SqlDbType.VarChar).Value = txtmobile.Text;
                cmd.Parameters.Add("@gender", SqlDbType.VarChar).Value = gender;
                cmd.Parameters.Add("@question", SqlDbType.VarChar).Value = question;
                cmd.Parameters.Add("@answer", SqlDbType.VarChar).Value = txtanswer.Text;
                
                con.Open();
                cmd.ExecuteNonQuery();
                con.Close();
                string msg1 = "alert('Account created Successfully...!!!');";
                ScriptManager.RegisterStartupScript(this, this.GetType(), "msg1", msg1, true);
               // Response.Redirect("index_user.aspx");
            }
            else
            {
                string msg1 = "alert('Account allready exist...!!!');";
                ScriptManager.RegisterStartupScript(this, this.GetType(), "msg1", msg1, true);
            }
        }
        catch (Exception ex)
        {
            //Response.Write(ex.Message.ToString());
            string msg1 = "alert('Account allready exist...choose other user name....!!!');";
            ScriptManager.RegisterStartupScript(this, this.GetType(), "msg1", msg1, true);
        }
    }
    protected void Button3_Click(object sender, EventArgs e)
    {
        txtFname.Text = " ";
        txtLname.Text = " ";
        txtUname.Text = " ";
        txtemail.Text = " ";
        txtpassword.Text = " ";
        txtcnfpassword.Text = " ";
        txtmobile.Text = " ";
        txtanswer.Text = " ";
        RadioButton1.Checked = false;
        RadioButton2.Checked = false;
        DropDownList1.SelectedIndex = -1;
    }
}